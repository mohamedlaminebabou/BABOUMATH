# MatrixBabou
  
This library is for matrix analysis and data mining. Its created to facilitate some of notable tools in linear algebra like the matriix decompositions and the classical products (Kronecker, Khatri-Rao, Hadamard..) , and all this function are accelerated.

## Installation
``` python3 -m pip install --user  MatrixBabou```

## How to use it?.
Work with matrices , Linear Algebra , Matrix decomposition .

## License

© 2021 

This repository is licensed under the MIT license. See LICENSE for details.
