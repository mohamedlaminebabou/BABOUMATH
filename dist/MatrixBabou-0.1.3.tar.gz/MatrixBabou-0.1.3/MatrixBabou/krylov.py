def gmres(A,b,err):
