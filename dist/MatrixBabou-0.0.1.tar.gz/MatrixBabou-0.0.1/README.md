# Babou math


## Installation
```pip install Baboumath```

## How to use it?
Work with matrices 

## License

© 2020 Udit Vashisht

This repository is licensed under the MIT license. See LICENSE for details.
