

This is a library of product of matrices accelerated by numba, very useful for Matrix analysis.
