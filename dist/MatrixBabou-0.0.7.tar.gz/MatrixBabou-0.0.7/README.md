# MatrixBabou
  
This library is for matrices analysis and data mining. Its created to facilite some of notable tools in linear algebra like the classical products (Kronecker, Khatri-rao,hadamard..) ,and we accelreate all this functions by Numba.

## Installation
``` python3 -m pip install --user  MatrixBabou==0.0.7```

## How to use it?
Work with matrices , Linear Algebra 

## License

© 2021 Udit Vashisht

This repository is licensed under the MIT license. See LICENSE for details.
