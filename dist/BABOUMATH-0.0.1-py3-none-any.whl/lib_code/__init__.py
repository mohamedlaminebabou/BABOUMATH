#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 22 10:56:42 2021

@author: babou
"""
import numpy as np 
from numba import prange , jit 
import os 
import sys
